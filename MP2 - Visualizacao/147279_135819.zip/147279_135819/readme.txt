//EA872 - LAB2
// Mariane Tiemi Iguti (RA147279) e Gabriela Akemi Shima (RA135819)

Primeiramente foi tratado quando o corpo ultrapassava os limites da tela, para que ele continuasse calculado sua posicao corretamente fazer a sua impressao. Depois foi adicionado o modelo fisico massa-mola do lab1.
Todo as linhas alteradas ou adicionadas sao acompanhados de comentarios '//edit:'. Para cada um dos 4 corpos criados na main foram atribuidos constantes k e b diferentes.
